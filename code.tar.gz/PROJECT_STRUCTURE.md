# תרשים מבנה הפרויקט - Support App

```
support/
│
├── 📁 src/                          # קוד המקור
│   │
│   ├── 📁 client/                    # אפליקציות הלקוח
│   │   │
│   │   ├── 📁 admin/                 # אפליקציית ניהול (Admin App)
│   │   │   ├── 📄 App.tsx            # רכיב האפליקציה הראשי
│   │   │   ├── 📄 App.css            # סגנונות האפליקציה
│   │   │   ├── 📄 main.tsx           # נקודת הכניסה
│   │   │   ├── 📄 index.html         # תבנית HTML
│   │   │   ├── 📄 index.css          # סגנונות גלובליים
│   │   │   ├── 📄 vite-env.d.ts      # הגדרות Vite
│   │   │   │
│   │   │   ├── 📁 components/        # רכיבי React
│   │   │   │   ├── 📄 ActionMenu.tsx
│   │   │   │   ├── 📄 DashboardToolbar.tsx
│   │   │   │   ├── 📄 LinkConfigModal.tsx
│   │   │   │   ├── 📄 LinksDashboard.tsx
│   │   │   │   ├── 📄 LinksTable.tsx
│   │   │   │   ├── 📄 LinkStatusChip.tsx
│   │   │   │   ├── 📄 Toast.tsx
│   │   │   │   └── 📄 ToastContainer.tsx
│   │   │   │
│   │   │   ├── 📁 hooks/            # React Hooks מותאמים אישית
│   │   │   │   ├── 📄 useBoardColumns.ts
│   │   │   │   ├── 📄 useBoards.ts
│   │   │   │   ├── 📄 useLinkMutation.ts
│   │   │   │   ├── 📄 useLinksFilter.ts
│   │   │   │   ├── 📄 useLinksIndex.ts
│   │   │   │   └── 📄 useNewRequestsStatus.ts
│   │   │   │
│   │   │   ├── 📁 services/         # שירותי API
│   │   │   │   └── 📄 api.ts
│   │   │   │
│   │   │   ├── 📁 types/            # הגדרות TypeScript
│   │   │   │   └── 📄 board.types.ts
│   │   │   │
│   │   │   ├── 📁 utils/            # כלי עזר
│   │   │   │   └── 📄 mappingValidator.ts
│   │   │   │
│   │   │   ├── 📄 tsconfig.json      # הגדרות TypeScript
│   │   │   └── 📄 tsconfig.node.json
│   │   │
│   │   ├── 📁 client/               # אפליקציית הלקוח (Client App)
│   │   │   ├── 📄 App.tsx
│   │   │   ├── 📄 App.css
│   │   │   ├── 📄 main.tsx
│   │   │   ├── 📄 index.html
│   │   │   ├── 📄 index.css
│   │   │   ├── 📄 clien_ui_ex.jsx    # דוגמה/ניסוי
│   │   │   ├── 📄 vite-env.d.ts
│   │   │   │
│   │   │   ├── 📁 components/       # רכיבי React
│   │   │   │   ├── 📄 ClientPanel.tsx
│   │   │   │   ├── 📄 RecordingPanel.tsx
│   │   │   │   ├── 📄 SetupScreen.tsx
│   │   │   │   ├── 📄 SupportScreen.tsx
│   │   │   │   └── 📄 VideoPreview.tsx
│   │   │   │
│   │   │   ├── 📁 hooks/            # React Hooks (ריק כרגע)
│   │   │   │
│   │   │   ├── 📁 services/         # שירותים
│   │   │   │   ├── 📄 api.ts
│   │   │   │   ├── 📄 db.ts
│   │   │   │   ├── 📄 monday-metadata.ts
│   │   │   │   └── 📄 validation.ts
│   │   │   │
│   │   │   ├── 📁 public/           # קבצים סטטיים
│   │   │   │   ├── 📄 agent.html
│   │   │   │   ├── 📄 db.js
│   │   │   │   └── 📄 RecordRTC.js
│   │   │   │
│   │   │   ├── 📁 types/            # הגדרות TypeScript (ריק כרגע)
│   │   │   │
│   │   │   ├── 📄 tsconfig.json
│   │   │   └── 📄 tsconfig.node.json
│   │   │
│   │   ├── 📁 shared/               # קוד משותף (ריק כרגע)
│   │   │
│   │   └── 📄 new_client_folder.md  # הערות/תיעוד
│   │
│   └── 📁 server/                   # שרת Backend
│       ├── 📄 index.ts              # נקודת הכניסה לשרת
│       ├── 📄 dev.ts                # שרת פיתוח
│       │
│       ├── 📁 routes/               # נתיבי API
│       │   ├── 📄 index.ts          # נתיב ראשי
│       │   ├── 📄 config.ts         # הגדרות
│       │   ├── 📄 links.ts          # ניהול קישורים
│       │   ├── 📄 oauth.ts          # אימות OAuth
│       │   ├── 📄 sessions.ts       # ניהול סשנים
│       │   ├── 📄 tickets.ts        # ניהול כרטיסים
│       │   └── 📄 upload.ts         # העלאת קבצים
│       │
│       ├── 📁 services/             # שירותי Backend
│       │   ├── 📄 monday.service.ts      # אינטגרציה עם Monday.com
│       │   ├── 📄 secure-storage.service.ts  # אחסון מאובטח
│       │   └── 📄 storage.service.ts      # שירות אחסון
│       │
│       ├── 📁 middleware/           # Middleware (ריק כרגע)
│       │
│       ├── 📁 types/                # הגדרות TypeScript (ריק כרגע)
│       │
│       └── 📁 utils/                # כלי עזר
│           ├── 📄 helpers.ts
│           └── 📄 logger.ts
│
├── 📁 shared/                       # קוד משותף בין Client ו-Server
│   │
│   ├── 📁 constants/                # קבועים
│   │   ├── 📄 index.ts
│   │   └── 📄 index.js
│   │
│   └── 📁 types/                    # הגדרות TypeScript משותפות
│       ├── 📄 index.ts
│       ├── 📄 index.js
│       ├── 📄 admin.types.ts
│       ├── 📄 admin.types.js
│       ├── 📄 api.types.ts
│       ├── 📄 api.types.js
│       ├── 📄 link.types.ts
│       ├── 📄 link.types.js
│       ├── 📄 ticket.types.ts
│       └── 📄 ticket.types.js
│
├── 📁 dist/                         # קבצים מהודרים (Build Output)
│   └── 📁 server/
│       ├── 📄 dev.js
│       ├── 📄 index.js
│       └── 📁 routes/               # קבצים מהודרים
│       └── 📁 services/
│       └── 📁 utils/
│
├── 📁 public/                       # קבצים סטטיים לפריסה
│   ├── 📁 admin/                    # אפליקציית Admin מהודרת
│   ├── 📁 client/                   # אפליקציית Client מהודרת
│   ├── 📁 index/                    # קבצים מהודרים נוספים
│   ├── 📁 src/
│   └── 📁 temp/                     # קבצים זמניים
│
├── 📁 SPEC/                         # תיעוד ומפרטים
│   ├── 📁 _docs/                    # מסמכי תיעוד
│   │   ├── 📄 ARCHITECTURE_COMPLIANCE.md
│   │   ├── 📄 bridge_architecture.md
│   │   ├── 📄 ENV_SETUP_GUIDE.md
│   │   ├── 📄 IMPLEMENTATION_SUMMARY.md
│   │   ├── 📄 link_manager_ui.md
│   │   ├── 📄 Manage.md
│   │   ├── 📄 MIGRATION_PLAN.md
│   │   ├── 📄 monday_api.md
│   │   ├── 📄 monday_get.md
│   │   ├── 📄 OAuth and Permissions.md
│   │   ├── 📄 Quotas and limits.md
│   │   ├── 📄 README.md
│   │   ├── 📄 reccorder.jsx
│   │   ├── 📄 Schedule.md
│   │   ├── 📄 Screen Recording Implementation.md
│   │   ├── 📄 Screen Recording.md
│   │   ├── 📄 Security.md
│   │   ├── 📄 server.md
│   │   ├── 📄 serverSDK.md
│   │   └── 📄 ...
│   │
│   ├── 📁 Phase0_Setup/             # שלב 0 - הגדרה
│   ├── 📁 Spiral1_Skeleton/         # ספירלה 1 - שלד
│   │   ├── 📁 Phase1.1_Types/
│   │   ├── 📁 Phase1.2_Server/
│   │   ├── 📁 Phase1.3_AdminApp/
│   │   ├── 📁 Phase1.4_ClientApp/
│   │   ├── 📁 Phase1.5_Integration/
│   │   └── 📁 Phase1.6_Verification/
│   │
│   ├── 📁 Spiral2_MVP/              # ספירלה 2 - MVP
│   │   ├── 📁 Phase2.1_Storage/
│   │   ├── 📁 Phase2.2_LinkManagement/
│   │   └── 📁 Phase2.3_ScreenRecording/
│   │
│   ├── 📁 Spiral3_Full/             # ספירלה 3 - מלא
│   │
│   ├── 📄 AGENT_INSTRUCTIONS.md
│   ├── 📄 ARCHITECTURE.md
│   ├── 📄 CURRENT_PLAN.md
│   ├── 📄 system.md
│   └── 📄 ex.html
│
├── 📁 node_modules/                 # תלויות (לא מוצג)
│
├── 📄 package.json                  # הגדרות הפרויקט ותלויות
├── 📄 package-lock.json             # נעילת גרסאות תלויות
├── 📄 tsconfig.json                 # הגדרות TypeScript כלליות
├── 📄 tsconfig.server.json          # הגדרות TypeScript לשרת
├── 📄 vite.config.ts                # הגדרות Vite
├── 📄 tailwind.config.js            # הגדרות Tailwind CSS
├── 📄 postcss.config.js             # הגדרות PostCSS
├── 📄 local-secure-storage.db.json  # מסד נתונים מקומי
└── 📄 README.md                     # קובץ README ראשי
```

## הסבר על המבנה

### 🎯 **src/client/admin/**
אפליקציית ניהול לניהול קישורים, לוחות וקונפיגורציות. כוללת:
- **components/**: רכיבי UI (טבלאות, מודלים, טולטיפים)
- **hooks/**: React Hooks לניהול state ו-API calls
- **services/**: שירותי תקשורת עם השרת

### 🎯 **src/client/client/**
אפליקציית הלקוח להקלטת מסך ותמיכה. כוללת:
- **components/**: רכיבי הקלטה ותצוגה
- **services/**: שירותי DB, validation ו-Monday metadata
- **public/**: קבצים סטטיים (RecordRTC, DB)

### 🎯 **src/server/**
שרת Express עם:
- **routes/**: נתיבי API (OAuth, links, sessions, tickets, upload)
- **services/**: שירותי Monday.com, אחסון מאובטח ואחסון כללי
- **utils/**: כלי עזר ולוגר

### 🎯 **shared/**
קוד משותף בין Client ו-Server:
- **types/**: הגדרות TypeScript משותפות
- **constants/**: קבועים משותפים

### 🎯 **dist/**
קבצים מהודרים לפריסה

### 🎯 **public/**
קבצים סטטיים מהודרים לפריסה ב-Monday.com

### 🎯 **SPEC/**
תיעוד מלא של הפרויקט, כולל:
- מסמכי ארכיטקטורה
- תוכניות מימוש
- הנחיות פיתוח

