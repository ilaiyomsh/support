/**
 * Link Types - מבני נתונים לניהול לינקים
 */
export {};
