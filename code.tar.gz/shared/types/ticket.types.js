/**
 * Ticket Types - מבני נתונים לפניות תמיכה
 */
export {};
