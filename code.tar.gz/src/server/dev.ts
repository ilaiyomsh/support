// Load environment variables from .env file
import 'dotenv/config';

// Dev server for testing Express during development
// This is imported with tsx in package.json scripts
import './index.ts';

