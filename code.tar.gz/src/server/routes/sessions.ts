import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

const router = Router();

// In-memory storage for sessions (in production, use Redis or database)
interface SessionData {
  sessionId: string;
  status: 'pending' | 'recording' | 'completed' | 'error' | 'cancelled';
  videoUrl?: string;
  createdAt: number;
  completedAt?: number;
  stopRequested?: boolean; // Flag to request recording stop from agent window
}

const sessions = new Map<string, SessionData>();

// Cleanup old sessions (older than 1 hour)
setInterval(() => {
  const oneHourAgo = Date.now() - 60 * 60 * 1000;
  for (const [sessionId, session] of sessions.entries()) {
    if (session.createdAt < oneHourAgo) {
      sessions.delete(sessionId);
      logger.info('Cleaned up old session', { sessionId });
    }
  }
}, 5 * 60 * 1000); // Run every 5 minutes

/**
 * POST /api/sessions
 * Create a new recording session
 */
router.post('/', (_req: Request, res: Response) => {
  try {
    const sessionId = uuidv4();
    const session: SessionData = {
      sessionId,
      status: 'pending',
      createdAt: Date.now()
    };

    sessions.set(sessionId, session);

    logger.info('Session created', { sessionId });

    res.json({
      success: true,
      sessionId
    });
  } catch (error: any) {
    logger.error('Error creating session', { error: error.message });
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * GET /api/sessions/:sessionId
 * Get session status
 */
router.get('/:sessionId', (req: Request, res: Response) => {
  try {
    const { sessionId } = req.params;
    logger.info('Get session request', { sessionId });
    
    const session = sessions.get(sessionId);

    if (!session) {
      logger.warn('Session not found', { sessionId });
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    logger.info('Session found', { 
      sessionId, 
      status: session.status,
      hasVideoUrl: !!session.videoUrl,
      createdAt: session.createdAt,
      completedAt: session.completedAt
    });

    res.json({
      success: true,
      status: session.status,
      videoUrl: session.videoUrl,
      createdAt: session.createdAt,
      completedAt: session.completedAt,
      stopRequested: session.stopRequested || false
    });
  } catch (error: any) {
    logger.error('Error getting session', { error: error.message, stack: error.stack });
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * PUT /api/sessions/:sessionId/status
 * Update session status (used by agent.html after upload)
 */
router.put('/:sessionId/status', (req: Request, res: Response) => {
  try {
    const { sessionId } = req.params;
    const { status, videoUrl } = req.body;

    logger.info('Update session status request', { 
      sessionId, 
      status, 
      hasVideoUrl: !!videoUrl,
      videoUrl: videoUrl ? videoUrl.substring(0, 100) : undefined
    });

    const session = sessions.get(sessionId);

    if (!session) {
      logger.warn('Session not found for status update', { sessionId, requestedStatus: status });
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    logger.info('Session found, updating status', { 
      sessionId, 
      oldStatus: session.status, 
      newStatus: status 
    });

    session.status = status;
    if (videoUrl) {
      session.videoUrl = videoUrl;
    }
    if (status === 'completed') {
      session.completedAt = Date.now();
      logger.info('Session marked as completed', { sessionId, completedAt: session.completedAt });
    }

    sessions.set(sessionId, session);

    logger.info('Session status updated successfully', { 
      sessionId, 
      status: session.status, 
      hasVideoUrl: !!session.videoUrl,
      completedAt: session.completedAt
    });

    res.json({
      success: true,
      sessionId,
      status: session.status
    });
  } catch (error: any) {
    logger.error('Error updating session status', { 
      error: error.message, 
      stack: error.stack,
      sessionId: req.params.sessionId
    });
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

/**
 * POST /api/sessions/:sessionId/stop
 * Request to stop recording (polled by agent.html)
 */
router.post('/:sessionId/stop', (req: Request, res: Response) => {
  try {
    const { sessionId } = req.params;
    logger.info('Stop session request', { sessionId });
    
    const session = sessions.get(sessionId);

    if (!session) {
      logger.warn('Session not found for stop request', { sessionId });
      return res.status(404).json({
        success: false,
        message: 'Session not found'
      });
    }

    logger.info('Session found, setting stop requested flag', { 
      sessionId, 
      currentStatus: session.status,
      wasStopRequested: session.stopRequested || false
    });

    session.stopRequested = true;
    sessions.set(sessionId, session);

    logger.info('Stop requested for session successfully', { sessionId });

    res.json({
      success: true,
      sessionId
    });
  } catch (error: any) {
    logger.error('Error requesting stop', { 
      error: error.message, 
      stack: error.stack,
      sessionId: req.params.sessionId
    });
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

export default router;

