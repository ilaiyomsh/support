export interface Board {
  id: string;
  name: string;
  type: string;
}

export interface Column {
  id: string;
  title: string;
  type: string;
}

