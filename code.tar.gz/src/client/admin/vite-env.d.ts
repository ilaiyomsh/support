/// <reference types="vite/client" />

declare module 'monday-sdk-js' {
  const monday: any;
  export default monday;
}

